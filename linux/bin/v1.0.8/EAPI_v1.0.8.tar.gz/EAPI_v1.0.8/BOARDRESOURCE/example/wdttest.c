/*************************************************************************
 > File Name: ledtest.c
 > Author: suchao.wang
 > Mail: suchao.wang@advantech.com.cn
 > Created Time: Thu 20 Nov 2014 05:40:53 PM CST
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <syslog.h>
#include "board_resource.h"

BR_HANDLE wdt_fd;
//void sigroutine(int dunno) {

//	if(dunno == SIGINT)
//		exit(-1);
//	BR_RESULT ret = BR_SUCCESS;
//	ret = WDT_Disable(wdt_fd);
//	if (ret != BR_SUCCESS)
//		printf("diable wdt fail[%d]\n", ret);
//	exit(-1);
//}
int main(int argc, char *argv[])
{
	printf("Press Ctrl+c to stop strobe watchdog \nthe system will reboot in 10 seconds\n");
	BR_RESULT ret = BR_SUCCESS;
	ret = WDT_Init(&wdt_fd);
	if (ret != BR_SUCCESS)
	{
		printf("open device fail[%d]\n", ret);
		return 0;
	}
	ret = WDT_Enable(wdt_fd,10);
	if (ret != BR_SUCCESS)
	{
		printf("enable wdt fail[%d]\n", ret);
		return 0;
	}

	WDT_SetMode(wdt_fd,WATCH_MODE_MANUAL,130);
	while(1){
		ret = WDT_Strobe(wdt_fd);
		if (ret != BR_SUCCESS)
		{
			printf("strobe wdt fail[%d]\n", ret);
			if(BR_DEVICE_ALREADY_OPENED == ret)
			{
				do
				{
					ret = WDT_Enable(wdt_fd,2);
					if (ret != BR_SUCCESS)
					{
						printf("enable wdt fail[%d]\n", ret);
					}else{
						printf("enable wdt success\n");
					}
				}while(ret != BR_SUCCESS);
			}
		}else{
			printf("strobe wdt success\n");
		}
		sleep(1);
	}

	return 0;
}
