/* ***************************************************************************
 *
 * testdl_hwmon.c : Defines the entry point for the console application.
 *
 * ***************************************************************************/

#include "atHWMON.h"
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <sys/file.h>
#include <syslog.h>

#define DEFAULT_LOCKFILE		"/var/run/test_hwmon.pid"
#define CMD_RETURN_BUF_SIZE		4096

void BoardGetValue(EApiId_t Id, uint32_t *pValue)
{
	EApiStatus_t status = EAPI_STATUS_SUCCESS;

	if (hDLL) {
		fnEApiBoardGetValue EApiBoardGetValue = NULL;
		EApiBoardGetValue = (fnEApiBoardGetValue)dlsym(hDLL,"EApiBoardGetValue");
		if (EApiBoardGetValue != NULL) {
			status = EApiBoardGetValue(Id, pValue);
		} else {
			printf("Dlsym Error : %s \n", __func__);
		}
	} else {
		printf("Dlopen Error : %s:%d ! \n", __func__, __LINE__);
	}

	if (status != EAPI_STATUS_SUCCESS) {
		printf("Error : %s:%d (0x00%X) \n", __func__, __LINE__, status);
	}
}

int CheckExit(const char *pFile)
{
	if (pFile == NULL) {
		return -1;
	}

	int LockFd = open(pFile, O_RDWR | O_CREAT);
	if (LockFd == -1) {
		return -2;
	}

	int iret = flock(LockFd, LOCK_EX | LOCK_NB);
	if (iret == -1) {
		return -3;
	}

	return 0;
}

int main(int argc, char* argv[])
{
	uint32_t Id = 0, Value = 0;

	switch (CheckExit(DEFAULT_LOCKFILE)) {
	default:
		break;
	case -1:
		printf("Paramener error! \n");
		return 0;
	case -2:
		printf("Open file error! \n");
		return 0;
	case -3:
		printf("Repeatedly call! \n");
		return 0;
	}

	hDLL = OpenEAPILIB();

	Id = EAPI_ID_HWMON_TEMP_CPU;
	BoardGetValue(Id, &Value);
	printf("BoardGetValue Id: 0x%X \nValue: %u \n", Id, Value);

	CloseEAPILIB(hDLL);
	return 0;
}
