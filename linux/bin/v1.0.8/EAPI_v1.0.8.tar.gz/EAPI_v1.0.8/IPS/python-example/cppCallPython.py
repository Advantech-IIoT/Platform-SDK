def testFunction(
        fwversion, 
        ips, 
        dcin, 
        battery, 
        inputlostdelay, 
        cutoffdelay, 
        batterylife,
        batteryvoltage,
        maxtemperature,
        temperature,
        capacity
        ):
    print("\n>>testFunction=================");
    print("fwversion: %s" %(fwversion));
    print("ips: %s" %(ips));
    print("dcin: %s" %(dcin));
    print("battery: %s" %(battery));
    print("inputlostdelay: %s" %(inputlostdelay));
    print("cutoffdelay: %s" %(cutoffdelay));
    print("batterylife: %s" %(batterylife));
    print("batteryvoltage: %s" %(batteryvoltage));
    print("maxtemperature: %s" %(maxtemperature));
    print("temperature: %s" %(temperature));
    print("capacity: %s" %(capacity));
    print("=============================<< \n");
    return 0;

