/* ***************************************************************************
 *
 * IPS-AE_Sample.cpp : Defines the entry point for the console application.
 *
 * ***************************************************************************/

#include "atIPSAE.h"
#include <sys/file.h>
#include <syslog.h>

#define DEFAULT_LOCKFILE	"/var/run/test_ipsae.pid"

using namespace EApiCommon;

class AdvIPSAEWorker : public IatCallBack {
	void atCallBack(CallBackType type, string str)
	{
		printf("==============================\ntype: %d\n%s\n==============================\n", type, str.c_str());
		if (type == EMERGENCY) {
			syslog(LOG_EMERG, "%s", str.c_str());
#if 0
		} else if (type == INFOMATION) {
			syslog(LOG_INFO, "%s", str.c_str());
#endif
		}
	};
};

void setTimetoDev(IatIPSAE *dev, int t1, int t2)
{
	if (NULL != dev) {
		printf("setDCinLostDelayTime result => %s\n", dev->setDCinLostDelayTime(t1).c_str());
		printf("setDCoutCutOffDelayTime result => %s\n", dev->setDCoutCutOffDelayTime(t2).c_str());
	}
}

void runIPS_AE(char *comport)
{
	IatIPSAE *patIPSAE = NULL;

	if (!EApiUPSGetDevice(&patIPSAE, comport)) {
		AdvIPSAEWorker *worker = new AdvIPSAEWorker();
		patIPSAE->setCallBack((IatCallBack *)worker);

		printf("start, there will send a callback automatically.....\n");
		setTimetoDev(patIPSAE, 300, 5);
	}
}

void byeIPS_AE()
{
	EApiUPSDelDevice();
}

int CheckExit(const char *pFile)
{
	if (pFile == NULL) {
		return -1;
	}
	
	int LockFd = open(pFile, O_RDWR | O_CREAT);
	if (LockFd == -1) {
		return -2;
	}

	int iret = flock(LockFd, LOCK_EX | LOCK_NB);
	if (iret == -1) {
		return -3;
	}

	return 0;
}

int main(int argc, char* argv[])
{
	if (argc != 2) {
		printf("Usage: %s \"[COM_PATH]\" \n", argv[0]);
		printf("  [COM_PATH] - /dev/tty*N \n");
		return -1;
	}

	switch (CheckExit(DEFAULT_LOCKFILE)) {
		default:
			break;
		case -1:
			printf("Paramener error! \n");
			return 0;
		case -2:
			printf("Open file error! \n");
			return 0;
		case -3:
			printf("Repeatedly call! \n");
			return 0;
	}

	runIPS_AE(argv[1]);
	getchar();
	byeIPS_AE();

	return 0;
}
