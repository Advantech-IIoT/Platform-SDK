/* ***************************************************************************
 *
 * testdl_ec.c : Defines the entry point for the console application.
 *
 * ***************************************************************************/

#include "atEAPI.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <syslog.h>
#include <dlfcn.h>

#define DEFAULT_LOCKFILE		"/var/run/test_ec.pid"
#define CMD_RETURN_BUF_SIZE		4096

void *hDLL = NULL;
typedef EApiStatus_t (*fnEApiBoardGetStringA)(EApiId_t Id, char *pBuffer, uint32_t *pBufLen);
typedef EApiStatus_t (*fnEApiGetCOMports)(PLATFORM_COMPORT **comports, unsigned int *len);
typedef EApiStatus_t (*fnEApiGetMemoryAvailable)(float *mem_available);
typedef EApiStatus_t (*fnEApiGetDiskInfo)(PDISK_INFO diskInfo);

//fnEApiGetMemoryAvailable EApiGetMemoryAvailable;
//fnEApiGetDiskInfo EApiGetDiskInfo;

void openDLL()
{
	hDLL = dlopen("libEAPI.so", RTLD_LAZY);
	if (hDLL == NULL) {
		printf("Line:%d Error : Failed load library ! \n", __LINE__);
	}
}

void closeDLL()
{
	if (hDLL) {
		dlclose(hDLL);
		hDLL = NULL;
	}
}

void getBoardString(EApiId_t Id)
{
	char *pBuffer = NULL;
	uint32_t bufLen = 0;
	EApiStatus_t ret = 0;

	if (hDLL) {
		fnEApiBoardGetStringA EApiBoardGetStringA;
		EApiBoardGetStringA = (fnEApiBoardGetStringA)dlsym(hDLL, "EApiBoardGetStringA");
		if (EApiBoardGetStringA != NULL) {
			// Alloc buffer
			pBuffer = (char *)malloc(CMD_RETURN_BUF_SIZE);
			if (pBuffer == NULL) {
				return;
			}
			bufLen = CMD_RETURN_BUF_SIZE;
			memset(pBuffer, 0, bufLen);

			// call EAPI func and print result
			ret = EApiBoardGetStringA(Id, pBuffer, &bufLen);
			printf("Id: %d \nret: %d \npBuffer: %s \nbufLen: %d \n", Id, ret, pBuffer, bufLen);

			// free buffer
			free(pBuffer);
		} else {
			printf("Line:%d Error : Failed load symbol EApiBoardGetStringA ! \n", __LINE__);
		}
	} else {
		printf("Line:%d Error : Failed load library ! \n", __LINE__);
	}
}

void getCOMports()
{
	PLATFORM_COMPORT *comports = NULL;
	unsigned int i = 0;
	unsigned int serialNum = 0;
	EApiStatus_t ret = 0;

	if (hDLL) {
		fnEApiGetCOMports EApiGetCOMports;
		EApiGetCOMports = (fnEApiGetCOMports)dlsym(hDLL, "EApiGetCOMports");
		if (EApiGetCOMports != NULL) {
			// call EAPI func and print result
			ret = EApiGetCOMports(&comports, &serialNum);
			printf("serialNum: %d \nret: %d \n", serialNum, ret);
			if (comports != NULL) {
				for (i = 0; i < serialNum; i++) {
					printf("[console-%d] %s \n", i, comports[i].name);
					printf("[console-%d] %s \n", i, comports[i].pnpId);
					printf("[console-%d] %s \n", i, comports[i].manufacturer);
					printf("[console-%d] %s \n", i, comports[i].locationId);
				}
				free(comports);
			}
		} else {
			printf("Line:%d Error : Failed load symbol EApiGetCOMports ! \n", __LINE__);
		}
	} else {
		printf("Line:%d Error : Failed load library ! \n", __LINE__);
	}
}

int CheckExit(const char *pFile)
{
	if (pFile == NULL) {
		return -1;
	}
	
	int LockFd = open(pFile, O_RDWR | O_CREAT);
	if (LockFd == -1) {
		return -2;
	}

	int iret = flock(LockFd, LOCK_EX | LOCK_NB);
	if (iret == -1) {
		return -3;
	}

	return 0;
}

int main(int argc, char* argv[])
{
	switch (CheckExit(DEFAULT_LOCKFILE)) {
	default:
		break;
	case -1:
		printf("Paramener error! \n");
		return 0;
	case -2:
		printf("Open file error! \n");
		return 0;
	case -3:
		printf("Repeatedly call! \n");
		return 0;
	}

	openDLL();
	getBoardString(EAPI_ID_BOARD_NAME_STR);
	getBoardString(EAPI_ID_BOARD_BIOS_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_EC_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_OS_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_CPU_MODEL_NAME_STR);
	getCOMports();
	closeDLL();

	return 0;
}
