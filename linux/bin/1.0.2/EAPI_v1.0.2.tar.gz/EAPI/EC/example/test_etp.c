/* ***************************************************************************
 *
 * test_etp.c : Defines the entry point for the console application.
 *
 * ***************************************************************************/

#include "atECETP.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <syslog.h>

#define DEFAULT_LOCKFILE		"/var/run/test_etp.pid"
#define CMD_RETURN_BUF_SIZE		4096

// return 0: unlocked
// return 1: locked
// return other: error
unsigned long isLocked(int SlaveAddr)
{
	EApiStatus_t status = 0;
	unsigned long lockStatus = 0; 

	if ((status = EApiGetLockStatus(SlaveAddr, &lockStatus))
			!= ERROR_SUCCESS) {
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return status;
	}
	printf("[ 0x%X is %s ] \n", SlaveAddr, lockStatus ? "LOCKED":"UNLOCKED");

	return lockStatus;
}

void setProtect(int SlaveAddr, bool protect)
{
	EApiStatus_t status = 0;
	char password[16] = "12345678";

	if ((status = EApiSetEepromProtect(SlaveAddr, protect, 
					(unsigned char *)password, strlen(password))) != ERROR_SUCCESS) {
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return;
	}
	printf("[ %s 0x%X ] \n", protect ? "LOCK":"UNLOCK", SlaveAddr);
}

void readDeviceData()
{
	EApiStatus_t status = 0;
	PETP_DATA pReadDeviceData = NULL;

	pReadDeviceData = (PETP_DATA)malloc(sizeof(ETP_DATA));
	if (pReadDeviceData == NULL) {
		printf("Error: malloc error (size: %lu) \n", (unsigned long)sizeof(ETP_DATA));
		return;
	}
	memset(pReadDeviceData, 0, sizeof(ETP_DATA));

	if ((status = EApiETPReadDeviceData(pReadDeviceData))
			!= ERROR_SUCCESS) {
		free(pReadDeviceData);
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return;
	}
	printf("read device data successful. \n");
	printf("DeviceOrderText: %-40.40s \n", pReadDeviceData->DeviceOrderText);
	printf("DeviceOrderNumber: %-10.10s \n", pReadDeviceData->DeviceOrderNumber);
	printf("DeviceIndex: %-3.3s \n", pReadDeviceData->DeviceIndex);
	printf("DeviceSerialNumber: %-15.15s \n", pReadDeviceData->DeviceSerialNumber);
	printf("OperatingSystem: %-40.40s \n", pReadDeviceData->OperatingSystem);
	printf("Image: %-40.40s \n", pReadDeviceData->Image);

	free(pReadDeviceData);
}

void writeDeviceData()
{
	EApiStatus_t status = 0;
	ETP_DATA writeDeviceData;

	memset(&writeDeviceData, 0, sizeof(ETP_DATA));
	memcpy(writeDeviceData.DeviceOrderText, "PR4100.01-0-11-NB1-AN-AA-0B-0NNN", 32);
	memcpy(writeDeviceData.DeviceOrderNumber, "R911123123", 10);
	memcpy(writeDeviceData.DeviceIndex, "AB1", 3);
	memcpy(writeDeviceData.DeviceSerialNumber, "7260123456789AB", 15);
	memcpy(writeDeviceData.OperatingSystem, "Ubuntu Core 64Bit A0", 20);
	memcpy(writeDeviceData.Image, "PR/VR4 Ubuntu Core image 1V01", 29);
	memcpy(writeDeviceData.Reverse, "Reverse", 7);

	if ((status = EApiETPWriteDeviceData(&writeDeviceData))
			!= ERROR_SUCCESS) {
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return;
	}
	printf("write device data successful. \n");
}

void readUserData()
{
	EApiStatus_t status = 0;
	PETP_USER_DATA pReadUserData = NULL;
	int i = 0;

	pReadUserData = (PETP_USER_DATA)malloc(sizeof(ETP_USER_DATA));
	if (pReadUserData == NULL) {
		printf("Error: malloc error (size: %lu) \n", (unsigned long)sizeof(ETP_USER_DATA));
		return;
	}
	memset(pReadUserData, 0, sizeof(ETP_USER_DATA));

	if ((status = EApiETPReadUserData(pReadUserData))
			!= ERROR_SUCCESS) {
		free(pReadUserData);
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return;
	}
	printf("read UserSpace1: (HEX)\n");
	for (i = 0; i < 128; i++) {
		if (i == 128 - 1) {
			printf("0x%02X\n", pReadUserData->UserSpace1[i]);
		} else {
			printf("0x%02X ", pReadUserData->UserSpace1[i]);
		}
	}

	printf("read UserSpace2: (HEX)\n");
	for (i = 0; i < 128; i++) {
		if (i == 128 - 1) {
			printf("0x%02X\n", pReadUserData->UserSpace2[i]);
		} else {
			printf("0x%02X ", pReadUserData->UserSpace2[i]);
		}
	}

	free(pReadUserData);
}

void writeUserData()
{
	EApiStatus_t status = 0;
	ETP_USER_DATA writeUserData = {
		{
			0x11, 0x22, 0x33, 0x44, 0x55, 
			0x66, 0x77, 0x88, 0x99, 0xAA, 
			0xBB, 0xCC, 0xDD, 0xEE, 0xFF
		},
		{
			0x11, 0x22, 0x33, 0x44, 0x55, 
			0x66, 0x77, 0x88, 0x99, 0xAA, 
			0xBB, 0xCC, 0xDD, 0xEE, 0xFF
		}
	};

	if ((status = EApiETPWriteUserData(&writeUserData))
			!= ERROR_SUCCESS) {
		printf("%s:%d Error (status: %d)! \n", __func__, __LINE__, status);
		return;
	}
	printf("write user data successful. \n");
}

int CheckExit(const char *pFile)
{
	if (pFile == NULL) {
		return -1;
	}

	int LockFd = open(pFile, O_RDWR | O_CREAT);
	if (LockFd == -1) {
		return -2;
	}

	int iret = flock(LockFd, LOCK_EX | LOCK_NB);
	if (iret == -1) {
		return -3;
	}

	return 0;
}

int main(int argc, char* argv[])
{
	switch (CheckExit(DEFAULT_LOCKFILE)) {
	default:
		break;
	case -1:
		printf("Paramener error! \n");
		return 0;
	case -2:
		printf("Open file error! \n");
		return 0;
	case -3:
		printf("Repeatedly call! \n");
		return 0;
	}

	if (isLocked(ETP_DEVICE_INFO_AREA)) {
		printf("Device info area is locked ! \n");
/*
 * Please use this function carefully.
 * setProtect func will unlock the device info area (default 
 * password is 12345678).Then device info area no longer have 
 * the write protected.
 */
		//setProtect(ETP_DEVICE_INFO_AREA, false);
/*
 * Please use this function carefully.
 * writeDeviceData func will re-write current device data value.
 * This process is irreversible.
 */
		//writeDeviceData();
	} else {
		printf("Device info area is unlocked ! \n");
/*
 * It will lock the device info area (default password is 12345678).
 */
		//setProtect(ETP_DEVICE_INFO_AREA, true);
	}
	readDeviceData();
	writeUserData();
	readUserData();

	return 0;
}
