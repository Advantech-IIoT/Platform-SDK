/* ***************************************************************************
 *
 * test_ec.c : Defines the entry point for the console application.
 *
 * ***************************************************************************/

#include "atEAPI.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>
#include <syslog.h>

#define DEFAULT_LOCKFILE		"/var/run/test_ec.pid"
#define CMD_RETURN_BUF_SIZE		4096

void getBoardString(EApiId_t Id)
{
	char *pBuffer = NULL;
	uint32_t bufLen = 0;
	EApiStatus_t ret = 0;

	// Alloc buffer
	pBuffer = (char *)malloc(CMD_RETURN_BUF_SIZE);
	if (pBuffer == NULL) {
		return;
	}
	bufLen = CMD_RETURN_BUF_SIZE;
	memset(pBuffer, 0, bufLen);

	// call EAPI func and print result
	ret = EApiBoardGetStringA(Id, pBuffer, &bufLen);
	printf("Id: %d \nret: %d \npBuffer: %s \nbufLen: %d \n", Id, ret, pBuffer, bufLen);

	// free buffer
	free(pBuffer);
}

void getCOMports()
{
	PLATFORM_COMPORT *comports = NULL;
	unsigned int i = 0;
	unsigned int serialNum = 0;
	EApiStatus_t ret = 0;

	// call EAPI func and print result
	ret = EApiGetCOMports(&comports, &serialNum);
	printf("serialNum: %d \nret: %d \n", serialNum, ret);
	if (comports != NULL) {
		for (i = 0; i < serialNum; i++) {
			printf("[console-%d] %s \n", i, comports[i].name);
			printf("[console-%d] %s \n", i, comports[i].pnpId);
			printf("[console-%d] %s \n", i, comports[i].manufacturer);
			printf("[console-%d] %s \n", i, comports[i].locationId);
		}
		free(comports);
	}
}

int CheckExit(const char *pFile)
{
	if (pFile == NULL) {
		return -1;
	}

	int LockFd = open(pFile, O_RDWR | O_CREAT);
	if (LockFd == -1) {
		return -2;
	}

	int iret = flock(LockFd, LOCK_EX | LOCK_NB);
	if (iret == -1) {
		return -3;
	}

	return 0;
}

int main(int argc, char* argv[])
{
	switch (CheckExit(DEFAULT_LOCKFILE)) {
	default:
		break;
	case -1:
		printf("Paramener error! \n");
		return 0;
	case -2:
		printf("Open file error! \n");
		return 0;
	case -3:
		printf("Repeatedly call! \n");
		return 0;
	}

	getBoardString(EAPI_ID_BOARD_NAME_STR);
	getBoardString(EAPI_ID_BOARD_BIOS_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_EC_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_OS_REVISION_STR);
	getBoardString(EAPI_ID_BOARD_CPU_MODEL_NAME_STR);
	getCOMports();

	return 0;
}
